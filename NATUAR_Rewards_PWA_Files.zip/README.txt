NATUAR PWA ADDITIONS

1) Add in <head>:
<meta name="theme-color" content="#F4EFE7">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="default">
<meta name="apple-mobile-web-app-title" content="NATUAR">
<link rel="manifest" href="manifest.json">
<link rel="apple-touch-icon" href="apple-touch-icon.png">

2) Before </body> add:
<script>
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => navigator.serviceWorker.register('./sw.js'));
}
</script>

3) For automatic customer updates, after loading the public QR card successfully,
refresh the same public card every 5 seconds with setInterval.
